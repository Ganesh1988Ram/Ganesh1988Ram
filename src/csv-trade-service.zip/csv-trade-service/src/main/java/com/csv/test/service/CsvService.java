package com.csv.test.service;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

public interface CsvService {

	void enrichTradeData(MultipartFile file, HttpServletResponse response);

}
