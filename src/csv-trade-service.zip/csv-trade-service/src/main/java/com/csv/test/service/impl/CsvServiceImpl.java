package com.csv.test.service.impl;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.csv.test.domain.Enrich;
import com.csv.test.domain.Product;
import com.csv.test.domain.Trade;
import com.csv.test.model.Property;
import com.csv.test.service.CsvService;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CsvServiceImpl implements CsvService {

	@Autowired
	protected Property property;
	@Autowired
	protected ResourceLoader resourceLoader;

	@Override
	public void enrichTradeData(MultipartFile file, HttpServletResponse response) {
		List<Trade> tradeList = readTradeDataFromCsv(file);
		if (!CollectionUtils.isEmpty(tradeList)) {
			Map<String, String> productMap = readProductDataFromCsv(property.getProductFilePath());
			if (!CollectionUtils.isEmpty(productMap)) {
				List<Enrich> enrichList = new ArrayList<>();
				Optional.ofNullable(tradeList).orElse(new ArrayList<>()).stream().forEachOrdered(trade -> {
					String productName = productMap.get(trade.getProductId());
					if (validateDateFormat(trade.getDate(), trade.getProductId(), productName)) {
						Enrich enrich = new Enrich();
						enrich.setCurrency(trade.getCurrency());
						enrich.setDate(trade.getDate());
						enrich.setPrice(trade.getPrice());
						enrich.setProductName(productName);
						enrichList.add(enrich);
					}
				});
				try {
					response.setContentType("text/csv");
					response.addHeader("Content-Disposition",
							"attachment; filename=\"" + property.getEnrichFileName() + "\"");
					response.getWriter().print(writeToCsv(enrichList));
				} catch (Exception e) {
					log.error("Exception in enrichTradeData: " + e);
				}
			}
		}
	}

	private List<Trade> readTradeDataFromCsv(MultipartFile file) {
		List<Trade> tradeList = new ArrayList<>();
		if (file != null) {
			CsvMapper csvMapper = new CsvMapper();
			CsvSchema csvSchema = CsvSchema.emptySchema().withHeader();
			ObjectReader objectReader = csvMapper.readerFor(Trade.class).with(csvSchema);
			try (Reader reader = new InputStreamReader(file.getInputStream())) {
				MappingIterator<Trade> iterator = objectReader.readValues(reader);
				while (iterator.hasNext()) {
					Trade trade = iterator.next();
					tradeList.add(trade);
				}
			} catch (Exception e) {
				log.error("Exception in readTradeDataFromCsv: " + e);
			}
		}
		return tradeList;
	}

	private Map<String, String> readProductDataFromCsv(String fileName) {
		Map<String, String> map = new HashMap<>();
		CsvMapper csvMapper = new CsvMapper();
		CsvSchema csvSchema = CsvSchema.emptySchema().withHeader();
		ObjectReader objectReader = csvMapper.readerFor(Product.class).with(csvSchema);
		Resource resource = resourceLoader.getResource(fileName);
		try (Reader reader = new InputStreamReader(resource.getInputStream())) {
			MappingIterator<Product> iterator = objectReader.readValues(reader);
			while (iterator.hasNext()) {
				Product product = iterator.next();
				map.put(product.getProductId(), product.getProductName());
			}
		} catch (Exception e) {
			log.error("Exception in readProductDataFromCsv: " + e);
		}
		return map;
	}

	private boolean validateDateFormat(String date, String productId, String productName) {
		boolean isValidDateFormat = false;
		DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendPattern("yyyyMMdd").parseStrict()
				.toFormatter();
		try {
			LocalDate.parse(date, formatter);
			isValidDateFormat = true;
		} catch (Exception e) {
			log.info("The product with Id - {} and Name - {} has invalid Date Format......!!", productId, productName);
		}
		return isValidDateFormat;
	}

	private String writeToCsv(List<Enrich> enrichList) throws IOException {
		CsvMapper csvMapper = new CsvMapper();
		CsvSchema csvSchema = csvMapper.schemaFor(Enrich.class).withHeader();
		return csvMapper.writerFor(List.class).with(csvSchema).writeValueAsString(enrichList);
	}
}