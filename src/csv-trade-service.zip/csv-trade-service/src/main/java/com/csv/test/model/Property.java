/**
 * =============================================================================
 * For internal use of SINGAPORE AIRLINES and TATA CONSULTANCY SERVICES only.
 * (C) 2021 Singapore Airlines.
 * Singapore Co. All Rights Reserved.
 *
 * Information in this file is the intellectual property of TATA CONSULTANCY SERVICES
 * and SINGAPORE AIRLINES.
 * =============================================================================
 */
package com.csv.test.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author TCS
 *
 */
@Configuration
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Property {
	@Value("${product.file.path}")
	private String productFilePath;
	@Value("${enrich.file.name}")
	private String enrichFileName;
}
