package com.csv.test.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"date", "product_name", "currency", "price"})
public class Enrich {
	@JsonProperty("date")
	private String date;
	@JsonProperty("product_name")
	private String productName;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("price")
	private String price;
}